Dog vs Cat Detector - folder structure
=====================================
Unzip this and upload the two folders (dog_cat_dataset, runs) to MyDrive on Google Drive.

MyDrive/
|-- dog_cat_dataset/
|   `-- dog_cat/
|       |-- train/
|       |   |-- images/   INPUT: put training photos here (cat... / dog... filenames)
|       |   `-- labels/   OUTPUT: label .txt files (created by the notebook)
|       `-- test/
|           |-- images/   INPUT (optional): test photos
|           `-- labels/   OUTPUT: created only if test images exist
`-- runs/                 OUTPUT: training results and best.pt (created by the notebook)

Notes:
- A cat photo must have "cat" in its filename. Anything else is treated as a dog.
- The notebook writes data.yaml itself. You do not need to create it.
