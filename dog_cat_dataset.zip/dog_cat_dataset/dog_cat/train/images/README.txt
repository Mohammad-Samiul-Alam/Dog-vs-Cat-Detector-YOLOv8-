Put train images here (.jpg / .png), e.g. cat_001.jpg, dog_001.jpg
