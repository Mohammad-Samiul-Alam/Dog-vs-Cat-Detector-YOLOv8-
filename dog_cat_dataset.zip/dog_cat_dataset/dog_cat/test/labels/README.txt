Put YOLO label files here (.txt), same names as images, e.g. cat_001.txt
Format: <class_id> <x_center> <y_center> <width> <height>  (0=cat, 1=dog, values 0-1)
